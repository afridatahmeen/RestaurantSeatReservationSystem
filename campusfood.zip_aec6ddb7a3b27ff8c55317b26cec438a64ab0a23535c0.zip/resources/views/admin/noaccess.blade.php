<div class="d-grid justify-content-center my-3">

    <img src="{{Helper::image_path('noaccess.png')}}" alt="" class="mx-auto mb-3 w-50">

    <h5 class="text-center text-muted mb-0">{{ trans('labels.no_access') }}</h5>

</div>