<script src="{{ url('storage/app/public/admin-assets/assets/js/jquery/jquery.min.js') }}"></script><!-- jQuery JS -->
<script src="{{ url('storage/app/public/admin-assets/assets/js/bootstrap/bootstrap.bundle.min.js') }}"></script><!-- Bootstrap JS -->
<script src="{{ url('storage/app/public/admin-assets/assets/js/toastr/toastr.min.js') }}"></script><!-- Toastr JS -->
<script src="{{ url('storage/app/public/admin-assets/assets/js/sweetalert/sweetalert2.min.js') }}"></script><!-- Sweetalert JS -->
<script src="{{ url('storage/app/public/admin-assets/assets/js/chartjs/chart_3.9.1.min.js') }}"></script>
<script src="{{ url('storage/app/public/admin-assets/assets/js/datatables/jquery.dataTables.min.js') }}"></script><!-- Datatables JS -->
<script src="{{ url('storage/app/public/admin-assets/assets/js/datatables/dataTables.bootstrap5.min.js') }}"></script><!-- Datatables Bootstrap5 JS -->
<script src="{{ url('storage/app/public/admin-assets/assets/js/datatables/dataTables.buttons.min.js') }}"></script><!-- Datatables Buttons JS -->
<script src="{{ url('storage/app/public/admin-assets/assets/js/datatables/jszip.min.js') }}"></script><!-- Datatables Excel Buttons JS -->
<script src="{{ url('storage/app/public/admin-assets/assets/js/datatables/pdfmake.min.js') }}"></script><!-- Datatables Make PDF Buttons JS -->
<script src="{{ url('storage/app/public/admin-assets/assets/js/datatables/vfs_fonts.js') }}"></script><!-- Datatables Export PDF Buttons JS -->
<script src="{{ url('storage/app/public/admin-assets/assets/js/datatables/buttons.html5.min.js') }}"></script><!-- Datatables Buttons HTML5 JS -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-Z47HEB289L"></script><!-- Global site tag (gtag.js) - Google Analytics -->
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'G-Z47HEB289L');
</script>